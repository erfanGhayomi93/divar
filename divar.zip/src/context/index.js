import {createContext} from 'react';

const context = createContext("defaultValue");

export default context;