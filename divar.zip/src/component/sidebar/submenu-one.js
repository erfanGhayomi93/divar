import React, { useContext } from "react";
import { Link } from "react-router-dom";
import context from "../../context";
import {menu} from "./data";

export default function SubmenuOne() {
  const contextConsumer = useContext(context);

  return (
    <ul className="submenu-1">
      {menu.map((item, ind) => (
        <li key={ind} onClick={() => contextConsumer.clickedFilter(item.route)}>
          <img src={item.iconUrl} alt={item.name}/>
          <Link to={item.route}>{item.name}</Link>
        </li>
      ))}
    </ul>
  );
}