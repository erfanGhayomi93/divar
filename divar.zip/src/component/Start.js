import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import Main from "./main/Main";
import axios from "axios";
import context from "./../context";
import Menu from "./header/Menu";
import HandleRouteSidebar from "./sidebar/HandleRouteSidebar";

export default function Start({ city }) {
  const [data, setData] = useState({});
  const [loading, setLoading] = useState(true);
  const [valueSearch, setValueSearch] = useState(null);

  useEffect(() => {
    const url = `https://api.divar.ir/v8/web-search/${city}`;
    forwardRequest(url);
  }, [city]);

  const forwardRequest = url => {
    setLoading(true);
    axios.get(url).then(
      response => {
        setData(response.data);
        setLoading(false);
      },
      error => {
        console.log(error);
        alert("در دریافت اطلاعات مشکلی به وجود آمده");
        setLoading(false);
      }
    );
  };

  const clickedFilter = category => {
    forwardRequest(`https://api.divar.ir/v8/web-search/tehran/${category}`);
  };

  let changeSearch = value => {
    setValueSearch(value);
  };

  

  return (
    <div className="wrapper">
      <context.Provider
        value={{ data, loading, clickedFilter, changeSearch, valueSearch }}
      >
        
        <header className="header">
          <Menu />
        </header>
        <section className="content">
          <main className="main">
            <Main />
          </main>
          <aside className="sidebar">
            <HandleRouteSidebar />
          </aside>
        </section>
      </context.Provider>
    </div>
  );
}
