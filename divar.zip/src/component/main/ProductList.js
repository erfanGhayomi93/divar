import React, { useContext } from "react";
import Product from "./Product";
import context from "./../../context";
import Loading from "../Loading";

export default function ProductList() {
  const { data, loading, valueSearch } = useContext(context);

  return (
    <div className="product-list">
      <div className="seo_details">
        {data.seo_details ? data.seo_details.title : ""}
      </div>
      {!loading ? (
        data.widget_list
          .filter(item => {
            if (valueSearch === null || !valueSearch.length) return true;

            if (item.data.title.includes(valueSearch)) return true;

            if (item.data.normal_text.includes(valueSearch)) return true;

            return false;
          })
          .map((product, index) => <Product key={index} value={product} />)
      ) : (
        <Loading />
      )}
    </div>
  );
}
