import React from "react";
import FilterAndSearch from "./FilterAndSearch";
import ProductList from "./ProductList";

export default function Main({ isLoading }) {
  return (
    <div>
      <FilterAndSearch />

      <ProductList />
    </div>
  );
}

