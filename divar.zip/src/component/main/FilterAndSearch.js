import React from "react";
import Search from "./Search";
import FilterList from "./FilterList";

export default function FilterAndSearch() {
  return (
    <div>
      <Search />
      
      <FilterList />
    </div>
  );
}
