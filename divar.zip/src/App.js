import React from "react";
import "./App.css";
import Start from "./component/Start";
import { BrowserRouter as Router} from "react-router-dom";

function App() {
  return (
    <Router>
      {/* <Link to="/tehran" /> */}

      {/* <Route path="/tehran"> */}
        <Start city = "tehran" />
      {/* </Route> */}
    </Router>
  );
}

export default App;
